# AI学習コントロールパネル

ゲーム本体とは別に、`dashboard/start.bat` をダブルクリックすると、参考のMAZEWARDと同じ構成の専用ウィンドウが開きます。`npm run dashboard` も同じ動作です。ChromeまたはEdgeのアプリモードを使用し、通常のタブやアドレスバーは表示しません。閲覧にPythonやGPUは不要です。ブラウザで使う場合は `npm run dashboard:server` → **http://localhost:5180**。

## ローカルGPUで学習

1. 初回のみ `dashboard/setup-gpu.bat` を実行。プロジェクトの `.venv` にCUDA版PyTorchを導入します。NVIDIAドライバーが必要です。
2. `dashboard/start.bat` を開き、右上の設定で「Local GPU（CUDA）」と世代数・対局数を保存。
3. 「▶ 学習開始」。自己対戦の盤面処理は並列Rust、ニューラルネットの推論と更新はGPUで実行します。
4. 「■ 停止」またはウィンドウを閉じて停止。確定済み世代から「再開」できます。進行中の世代は破棄されます。

既定の世代数は **0（無制限）**。20世代で停止せず、停止操作まで評価と保存を挟みながら続きます。0のまま再開すると、保存した次の世代から継続します。回数を指定した実験だけ、正の世代数を設定してください。CPUの短い動作確認は1世代で完了します。

既定はGPUを明示指定し、GPUが使用できない場合は開始を止めて環境設定を案内します。CPUへ黙って切り替えません。「自動」を選んだ場合だけCUDA検出で切り替えます。設定画面のGPU表示は実際のCUDA行列演算を確認した結果です。「詳細」でPython・PyTorch・CUDAを確認できます。

このPCはRTX 3050 / 8 GB、PyTorch 2.11.0+cu128（公式Windowsホイール）を使用します。ローカル設定は `dashboard/local.json`、起動エラーは `.cache/dashboard/launcher.log`。初期ポート5180が使用中の場合は空きポートを選びます。ウィンドウ用プロファイルは普段のChrome/Edgeと独立しています。

## 最初に使う

1. ダッシュボードの「Colab・Drive連携」でノートブックと現在のソースZIPを保存する。
2. Google Colabへノートブックをアップロードし、GPUランタイムを選ぶ。最初のセルで `shogi-colab.zip` を渡す。
3. セルを順に実行する。学習はColabの一時ディスク上、確定した世代の保存先は `MyDrive/Simultaneous_Shogi/runs/<RUN_NAME>`。
4. 最終セルで取得した `shogi-results.zip` をローカル画面へ取り込む。Drive for desktopを使う場合は同期した `runs` の絶対パスを画面へ設定する。
5. 世代別成績、損失、処理時間、棋譜、戦術局面を確認する。「棋力の評価・比較」ではモデルをローカルCPUで追加評価できる。

ソースZIPにはRust核・CLI・学習コード・ルール・ノートブックを含めます。ColabにローカルPCへのトンネルを公開する操作はありません。ローカル画面は取得済みのファイルを読みます。進行中のColabの世代を逐次遠隔操作する機能はありません。

## ローカル実行の準備

Python 3.11以上、Rust、Node.js 20以上を使用します。ローカルGPUは上のセットアップを使用し、Colabでは付属のPyTorch/CUDAを使います。CPUのみの検証環境の作成例：

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install numpy torch --index-url https://download.pytorch.org/whl/cpu
npm run ai:build
npm run dashboard
```

Windowsの `python` がMicrosoft Storeのエイリアスを指す場合は、インストール済みPythonのフルパスで最初のコマンドを実行します。このPCでは `C:\Users\tomik\AppData\Local\Programs\Python\Python311\python.exe` で仮想環境を作成・検証しました。ダッシュボードは `.venv` を優先し、`SHOGI_PYTHON` で実行ファイルを指定することもできます。

画面の「CPUで動作確認」は2局・12ラウンド上限・小型モデル・1世代で、学習と4種類の対戦評価の動作を確かめます。この短縮実行は画面で「動作テスト」と表示し、基準モデルの昇格を禁止します。

```powershell
.venv\Scripts\python.exe -m training.train --run-dir dashboard/runs/my-test --smoke
.venv\Scripts\python.exe -m training.train --run-dir dashboard/runs/my-training --config training/config.json
```

正式ルールの版と既定制限は、ビルドしたRustの `training/hello` から取得します。作業中に正式版がv0.5からv0.6へ更新されたため、Pythonに版を固定する実装を廃止しました。v0.6では昇格済みの任意成りが無効、行き場を失う位置の強制成りは有効です。低水準APIで許可された3種類の変更指定は全列挙のままです。

## 学習と計算の配分

`training/config.json` が開始設定です。既定では8環境を2つの永続Rustプロセスに分け、推論はPython側へまとめます。CUDAがあればGPU、なければCPUを実際に使用します。GPU時のみFP16 AMPとTF32を有効にします。GPU利用率を推測して表示することはありません。

各局面で両者の全指定可能手を生成し、ネットの上位候補と探索枠から各4〜8候補を選びます。両者の候補の全組み合わせを正式解決器で1ラウンド進め、終局は正確な勝敗、それ以外は価値ネットで評価します。regret matchingによる平均混合戦略を方策の学習目標にします。**交互着手MCTS、完全ゲームのNash解、最適戦略の保証は実装していません。**

- 深い探索を既定25%の局面に配分し、王への到達候補があれば探索を広げる。探索枠は全候補から抽選し、モデルが低く評価する行動も調べる。
- 完了した対局だけに最終勝敗の価値目標を付ける。途中打ち切りを引き分けと偽って学習しない。
- 過去6チェックポイントから世代ごとに相手を抽選。既定25%の対局で片側を過去方策とし、その側のサンプルを現在の方策ターゲットに混ぜない。過去相手は探索なしの方策抽選で、現在モデルの探索相手と同じ強さではない。
- 最大4,096局面のリプレイ。直近2世代と全期間の一様抽選を混ぜ、同じ観測・行動特徴量は新しい教師で置換する。TD誤差の優先度付きリプレイは未実装。
- 長い対局からは静かなサンプルを最大96件に制限し、捕獲・衝突局面は保持。左右反転の対称性によるデータ拡張を行う。
- 初期の駒得・王接近の手作り評価は探索の初期補助としてのみ使用し、設定した世代数に応じて0まで減らす。価値の教師は実際の最終結果。
- 評価は初回・既定5世代おき（有限回数の実験は最終回も評価）。重みと再開用状態は毎世代保存。

既定値はColabで測定済みの最適設定ではありません。候補数・環境数・バッチ数を変更した実行は、別のRUN_NAMEで比較してください。

## 棋力の評価

同一の候補数・regret反復数・局面評価条件で、陣営を交換した2局を1ペアとします。乱数列は陣営交換後も方策の役割に追従します。混合戦略は評価中も抽選し、単純な最大確率手への置換は行いません。相手の今回の指定は探索へ渡しません。

固定方策 `hunter / defense / upgrade` と基準チェックポイントに対して評価します。得点率は `(勝ち + 0.5 × 引き分け) / 局数`。ペアを独立単位にした保守的なHoeffding区間を保存します。基準モデルの昇格判定は、無制限学習では評価の通算i回目に `alpha=0.05/(i*(i+1))` を配分し、停止時期にかかわらず総誤判定予算を0.05以下に保ちます。有限の実験は事前の判定回数で補正します。再開時も通算世代から同じ予算を引き継ぎます。基準対戦の種も世代ごとに変更します。少ないペア数では「判定保留」が普通で、上達の断定を避けます。固定相手への追加評価の表示区間は多重比較を補正しません。

正式なラウンド制限で区間下限が50%を超えたときだけchampionを更新します。学習自体は判定保留でも続きます。単一のchampionに勝つことは、すべての相手への優位や相性循環の解消を保証しません。固定相手ごとの成績も確認します。

無制限学習では、有意水準を小さくし続けても全勝時に昇格判定が可能なよう、基準モデル戦だけ評価ペア数の下限を対数的に増やします。固定3方策の評価ペア数は設定値のままです。

```powershell
.venv\Scripts\python.exe -m training.evaluate --run-dir dashboard/runs/my-training --opponent hunter --pairs 64
.venv\Scripts\python.exe -m training.evaluate --run-dir dashboard/runs/my-training --opponent champion --pairs 64
```

結果は `local-evaluations` に保存し、Colabでの昇格記録を変更しません。世代を指定する場合は `--checkpoint 5`、既定は最新です。モデル同士の直接対戦では、双方に同じ探索予算を与えます。固定方策は既存ヒューリスティックなので同じ計算時間ではありません。

## モデルの保存先と選択

ローカル学習の保存先は `dashboard/runs/<実行名>/checkpoints/gNNNN.pt` です。Colabでは `MyDrive/Simultaneous_Shogi/runs/<RUN_NAME>/checkpoints/` に退避します。各実行の `manifest.json` の `latest_checkpoint` が最後に確定した世代、`champion_checkpoint` が対戦評価の基準モデル（初期世代から始まり、昇格条件を満たした世代へ更新）を指します。再開と追加評価は既定で最新を使い、追加評価の `--checkpoint N` で世代を選べます。

ゲーム本体の「AI対戦」から実行名と世代を選び、「モデルを読み込んで対局」で人間と対局できます。最新とchampionを表示し、初期選択は最新。学習中の新しい世代は「一覧を更新」で反映し、進行中の対局は選択したモデルを固定します。Colabの結果は、この画面でZIPを取り込むか、Driveの同期フォルダーを設定するとゲームの一覧にも表示されます。

ゲームサーバーを起動したPCのlocalhostから利用します。ゲームのモデル読み込みは入出力形式・重み・ルールハッシュを検証し、ルール・ラウンド制限が異なる動作確認用モデルは選択できません。学習専用コードの変更に伴うソース識別子の違いは推論時には許容します。学習再開と追加評価のソース一致条件は従来どおりです。基本AIとの対戦機能は削除しました。接続試験は `npm run test:models`。

## 中断・再開と転送

学習の停止は実行フォルダー内の `STOP` またはSIGINTで依頼できます。進行中の世代を破棄し、最後に確定した世代から再開します。モデル・AdamW・AMP scaler・PyTorch/NumPy乱数状態・数値リプレイを保存し、最後にmanifestのポインターを更新します。2世代分のリプレイと全チェックポイントを保持します。

画面の再開ボタンは停止マーカーを消してから起動します。CLIで再開する場合は、その実行が停止済みであることを確認して `STOP` を削除し、**同じ設定ファイル**で実行します。

```powershell
.venv\Scripts\python.exe -m training.train --run-dir dashboard/runs/my-training --config training/config.json --resume
```

同じ実行への同時書き込みは `RUNNING` の排他作成で防ぎます。強制終了で残った場合は、既存プロセスの停止を確認してからこのマーカーを削除します。Driveへの退避は単一Colabセッションを前提とし、複数マシン間の分散ロックではありません。

Windowsの一時的なファイルロック（WinError 5 / 32 / 33）では、進捗JSON・モデル・リプレイ・Drive退避のアトミック置換を最長5秒まで再試行します。待機中も直前の保存ファイルを維持します。恒久的なアクセス拒否や別種のエラーは通知して停止します。

保存処理修正前の実行を引き継ぐ場合は `python -m dashboard.recover_io --run-dir dashboard/runs/元の実行 --destination dashboard/runs/元の実行-recovered` を使用できます。元のソースZIPと構文を比較し、I/Oの置換呼び出し以外に変更がある場合は拒否します。元データを残し、モデル・最適化器・乱数状態の一致を検証したコピーと復旧記録を作成します。学習アルゴリズムやルールの変更を無視して再開する機能ではありません。

Colabからの再開はノートブックがDriveの確定状態を新しいローカル作業フォルダーへ戻します。`--mirror-dir` は確定世代・停止時・終了時に退避し、manifestを最後にコピーします。各ラウンドの同期書き込みを避けています。Driveの転送失敗時は実行をエラーとして止め、ローカルに残ったチェックポイントを取得して復旧します。

```powershell
.venv\Scripts\python.exe -m training.transfer export --run-dir dashboard/runs/my-training --archive shogi-results.zip
.venv\Scripts\python.exe -m training.transfer import --run-dir dashboard/runs/imported --archive shogi-results.zip
```

ソース・ルール・モデル入出力の識別子が異なる結果は閲覧可能ですが、現在のコードで再評価・再開はしません。各実行の `source.zip` に学習時のコードを保存し、画面から保存できます。異なる版を黙って新ルールとして解釈しません。チェックポイントは `weights_only=True`、リプレイは `allow_pickle=False` で読みます。

## 原因を調べる・ルールを比較する準備

「棋譜・原因分析」は棋譜全体のハッシュ連鎖をRustで検証してから、ラウンド・段階・捕獲理由を表示します。持ち駒表示はラウンド解決後の値です。王の個数だけで勝敗を推測せず、正式解決器の結果を使います。

自己対戦で捕獲・衝突が起きた最初の最大8局面/世代には、入力局面、双方の候補、利得行列、混合戦略、実際の手、捕獲とイベントを保存します。保存棋譜は世代ごとの代表2局です。全局の棋譜は保存していません。

画面の「候補を広げて再分析」は、選んだ棋譜の当該ラウンド直前までを再実行し、反復履歴を保って最新モデル・16×16候補で探索し直します。元の実際の指定を双方の候補へ必ず含めるので、ネットが低く評価して候補外にした手も分析します。元の学習時の判断との比較では、使用世代・探索量の違いに注意します。

```powershell
.venv\Scripts\python.exe -m training.probe --run-dir dashboard/runs/my-training --replay dashboard/runs/my-training/games/g0001-000.json --round 3 --candidates 16
```

`restricted_gap` は**現在の候補行列の中だけ**の最適応答差です。候補外の反撃、先のラウンド、ネットの誤評価を含む完全ゲームのexploitabilityではありません。強い動きの存在やルール不均衡はこれだけで断定できません。

実行を比較するときはルールハッシュごとに分け、探索予算・種・ソース・ハードウェアを並べて確認します。代替ルールは次の「ルール比較」から独立した実行として学習・評価できます。

## A/B/B+/C/C+/D/D+を比較する

設計と実験計画は [BALANCE_EXPERIMENTS.md](../BALANCE_EXPERIMENTS.md)。ダッシュボードを再起動し、「ルール比較」を開きます。

1. 比較元の実行を選んで「最新世代から比較を作成」。その時点の確定済みチェックポイントとソースを固定します。元の学習実行は変更しません。
2. 「同じ重みで短期比較」で各ルールを評価。初期重みは保存されるため、学習開始後でもこの比較を実行できます。
3. 到達世代を指定して「各ルールで学習」。0は停止まで継続。各ルールは独立したモデル・optimizer・リプレイ・過去相手・championを持ちます。既定は2プロセスを並列実行し、5世代ずつ公平に交代します。全条件を同時に動かす場合は並列数を条件数に設定します。
4. 停止後に「適応後の長期比較」。最新世代を固定し、同じルールに適応したAI同士と初期重みとの陣営交換対戦を行います。
5. 「比較ログZIPを保存」で棋譜・集計・圧縮ラウンドログ・比較元モデル・学習ソースをまとめて渡せます。

ログZIPは全棋譜・全ラウンドの証拠を含み、モデルは初期・最新・champion・明示的な短期/長期比較で使った世代だけを含みます。数値リプレイと途中世代のモデルは元フォルダーに保持し、共有ZIPの肥大化を避けます。学習状態もすべて含める場合はCLIの `export --full-state` を指定してください。

短期と長期は既定で各512ペア（1024局）/条件、異なる評価種を使います。適応中にも5世代おきにchampion・適応モデル同士・初期重みとの評価を保存します。世代番号は分岐後の追加世代で、元の世代は `manifest.parent.generation` に保存します。学習曲線は同じ追加世代・計算予算で比較してください。

CLIの例（Windows以外は `.venv/bin/python` を使用）：

```powershell
.venv\Scripts\python.exe -m training.experiments init --directory dashboard/runs/experiments/balance-001 --source-run dashboard/runs/元の実行 --checkpoint latest
.venv\Scripts\python.exe -m training.experiments run --directory dashboard/runs/experiments/balance-001 --stage short
.venv\Scripts\python.exe -m training.experiments run --directory dashboard/runs/experiments/balance-001 --stage train --generations 50
.venv\Scripts\python.exe -m training.experiments run --directory dashboard/runs/experiments/balance-001 --stage long
.venv\Scripts\python.exe -m training.experiments export --directory dashboard/runs/experiments/balance-001 --output balance-logs.zip
```

停止はダッシュボードの停止ボタンまたは実験ルートの `STOP`。再実行前に実験ルートの `STOP` を削除します。同じ `run --stage train` で確定世代から続けます。失敗した条件がある場合は兄弟の学習にも通常停止を依頼します。実験ルート・子実行の `RUNNING` は同時書き込みを防ぎます。

`init --plan plan.json` の例：

```json
{
  "rules": ["A", "B", "B+", "C", "C+", "D"],
  "rule_overrides": {
    "B": {"consecutiveThreshold": 4},
    "C": {"homeRows": 3, "defensePosition": "round_start", "defenseCap": 7}
  },
  "grid": {
    "movement": ["upgrade_only", "progressive"],
    "consecutiveThreshold": [2, 3, 4],
    "defenseBonus": [1, 2],
    "homeRows": [2, 3, 4],
    "defensePosition": ["round_start", "stage_from", "destination"]
  },
  "seeds": [20261020, 20261021],
  "max_parallel": 2,
  "short_pairs": 512,
  "long_pairs": 512,
  "training": {"device": "cuda", "generations": 0}
}
```

`defenseCap:null` は格7超えを許可、7は上限7です。B+の+1スケールでは8を上限に指定します。D+の格子は指定した有限集合の全組み合わせを列挙し、同一条件を除きます。1計画512組み合わせを超える場合は分割してください。既定10条件ではD+として B+C+、B++C、B++C+、閾値2のB+Cを比較します。

保存先は `dashboard/runs/experiments/<実験名>/`：

| ファイル | 内容 |
| --- | --- |
| `experiment.json`, `configs/` | 比較元の世代・SHA、全条件、学習種、評価種、探索予算 |
| `runs/<条件>/manifest.json` | 追加世代、元モデル、ルール全文と識別子 |
| `runs/<条件>/games/gNNNN-*.json` | 実験の全自己対戦の再検証可能な棋譜 |
| `runs/<条件>/evidence/gNNNN/rounds.jsonl.gz` | 全ラウンドの前後状態、格・疲労、実際の行動、移動成否、衝突、捕獲、候補・混合戦略 |
| `runs/<条件>/evidence/gNNNN/summary.json` | 各局の昇格・生存期間・温存・所有側勝敗と集計 |
| `runs/<条件>/comparisons/short/`, `long/` | 重み固定比較／適応後比較と全評価棋譜 |
| `report.json`, `report.csv` | 短期・長期を分けた比較表。JSONに母数、右打ち切り、陣営交換ペア単位の記述区間 |

未確定世代の記録は学習の根拠に含めません。`manifest.generation` 以下が確定分です。元の54平面モデルは保存ソースの既知v0.6を照合して読み込み、追加8平面の入力重みを0にして62平面へ拡張します。元の重みを上書きせず、新ルールへoptimizerや旧ルールの数値リプレイを持ち込みません。

格7は「永続昇格した飛車・角」で統一します（B+の表示格は8）。終局時生存は右打ち切り、保有側勝率は片側だけ獲得・双方獲得・最初の獲得者・保有ラウンドを区別します。温存率の分母はその局面で少なくとも1段階は進める手があった格7駒ラウンドです。戦略の意図や格7獲得の因果効果はこれだけでは断定しません。

## 構成と検証

| ファイル | 役割 |
| --- | --- |
| `dashboard/server.mjs`, `dashboard/web/` | localhost専用APIと日本語UI |
| `crates/shogi-core/src/training.rs` | 説明文字列を作らない完全行動集合の高速生成 |
| `crates/shogi-core/src/game.rs` | 履歴を含む探索用preview |
| `crates/shogi-cli/src/training.rs` | 永続JSONLバッチ環境・同時候補の解決 |
| `training/features.py`, `model.py`, `search.py` | 相対盤面、疎な行動表現、ネット、同時探索 |
| `training/train.py`, `replay.py`, `evaluate.py` | 自己対戦、再利用、学習、保存、対戦評価 |
| `training/probe.py`, `transfer.py` | 履歴付き局面再分析・ZIP転送 |
| `training/research.json`, `TRAINING_RESEARCH.md` | 一次資料と採用・保留理由 |

```powershell
cargo test --workspace --locked
.venv\Scripts\python.exe -m unittest discover -s tests -p test_training.py -v
npm run test:dashboard
```

Rustの全行動集合・候補順の同値性、300ラウンド、上限・反復を含むpreview一致、混合戦略の既知解、盤面対称性、実学習による重み更新、数値リプレイ保存、中断再開後の更新一致、ZIP転送を検証します。API/DOM結合試験は一時フォルダーで本物のCPU学習を実行し、即時停止・再開・4相手評価・棋譜検証・追加評価・16×16分析・転送・全画面切替を確認します。実ブラウザーの描画確認とColab/CUDAでの実走は、この環境では未実施です。
